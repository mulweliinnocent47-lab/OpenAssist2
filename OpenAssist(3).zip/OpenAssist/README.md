# OpenAssist

OpenAssist is a native Android AI assistant prototype built with Kotlin, Jetpack Compose, MVVM, Retrofit, OkHttp, Coroutines, StateFlow, EncryptedSharedPreferences, and Material 3.

## Principles

- Bring your own OpenRouter API key.
- No backend, Firebase, Supabase, user accounts, cloud database, or subscription system.
- Store API keys, selected model, and preferences locally on the device.
- Route chat requests directly from Android to OpenRouter.
- Keep a small extensible tool layer for future Android actions and MCP server support.

## Implemented v1 Skeleton

- Onboarding screen for explaining OpenRouter costs and saving the API key locally.
- Settings screen for changing the API key and selected OpenRouter model.
- Chat screen with conversation history, loading state, and error display.
- OpenRouter repository using the Chat Completions endpoint.
- Tool interfaces plus initial device/app tools and confirmation-aware sensitive tool handling.

## OpenAssist v2 AI Modes

OpenAssist supports three AI modes:

- Cloud AI: uses OpenRouter with a user-supplied API key and OpenRouter model selection.
- Local AI: runs downloaded Hugging Face GGUF models offline on device through the planned llama.cpp Android provider.
- Hybrid AI: routes simple prompts to the local provider and complex prompts to OpenRouter based on user-configurable behavior.

Local model files are organized under app storage using this structure:

```text
OpenAssist/
├── models/
│   ├── gemma-2b.gguf
│   ├── smollm2.gguf
│   └── phi4-mini.gguf
├── cache/
├── downloads/
└── chat_history/
```

## OpenAssist v3 Autonomous Assistant & Safety System

OpenAssist v3 turns the prototype into a safety-first Android assistant. It can prepare app actions, summarize the visible screen, and provide a hold-Home voice overlay, but it must never execute sensitive actions silently.

### Safety core

- Sensitive actions always require user confirmation before execution.
- Messages, calls, file operations, payments, contacts, permissions, external sharing, and app automation stay under user control.
- File access is read-only by default. Advanced file access can be enabled in Settings, but delete, move, rename, replace, and bulk edit actions still require confirmation.

### Screen Intelligence Mode

Screen Intelligence is designed to read visible screen content only after a privacy warning and user-approved screen capture/accessibility setup. The feature can summarize the current screen, explain app content, answer questions about visible text, and extract OCR text for article or page summaries.

### Action and multi-step automation

OpenAssist can gather missing details before acting. For example, if the user asks to send a WhatsApp voice message, the assistant first asks what to say, prepares the action summary, and then shows final Approve/Cancel controls before any execution.

### Permission levels

1. Safe: read screen, open apps, and read notifications after approval.
2. Interactive: prepare messages, calls, file sharing, and app interactions with confirmation.
3. Advanced: file modifications, system automation, and accessibility actions with explicit approval.

### Assistant overlay, memory, and personality

OpenAssist is intended to be available from the Android assistant gesture or hold-Home action as a small animated voice-chat layer instead of forcing the full app to open. In-app memory lets users ask OpenAssist to remember preferences and tune the assistant personality while keeping control of stored memories.

## OpenAssist v5 Workspace, Canvas, Code Runner & Content Studio

OpenAssist v5 adds a workspace layer so large outputs do not overflow chat. Long code, generated projects, documents, images, archives, data files, and interactive content become workspace artifacts instead of oversized chat bubbles.

### Workspace system

The Workspace manages generated files, projects, images, documents, code, downloads, and recent creations. The assistant can create documents, code files, images, spreadsheets, presentations, diagrams, ZIP archives, and project folders under organized `workspace/` paths.

### Canvas behavior

Large content should open in a dedicated Canvas automatically. Code opens in Code Canvas, business plans open in Document Editor, websites and apps open in Project Explorer, images open in Image Studio, and run logs open in Output Console.

### Python runner safety

Python execution is designed around a sandbox approval step. By default, scripts cannot delete files, modify the system, use root access, access the network, or run in the background without approval. Before execution, OpenAssist shows the script name, estimated runtime, resource usage, and Approve/Cancel controls.

### Artifact system

Every generated item becomes an artifact: code, image, document, project, data, archive, spreadsheet, presentation, or diagram. Artifacts can be opened, renamed, duplicated, exported, deleted, and shared, with destructive actions still requiring confirmation.

### Content studio vision

OpenAssist should feel like ChatGPT plus Cursor, VS Code, Google Assistant, a file manager, an image generator, and a personal AI operating system in one premium Android workspace.

## OpenAssist v6 MCP Platform, Marketplace & Desktop Bridge

OpenAssist v6 introduces an MCP ecosystem so users can install, manage, and use external tools like apps. Built-in connections include GitHub, Google Drive, Notion, Discord, Telegram, Slack, Home Assistant, Google Calendar, Gmail, Dropbox, OneDrive, Jira, Linear, YouTube, Reddit, Spotify, OpenAI, OpenRouter, and Hugging Face.

### MCP marketplace and connections

The MCP Marketplace supports browsing, search, categories, ratings, verified badges, version information, updates, install, remove, enable, and disable actions. Normal users see simple Connections while advanced users can add custom HTTPS or local-network MCP endpoints, discover tools, import schemas, test health, inspect tools, and set manual permissions.

### MCP discovery and permissions

When a connection is added, OpenAssist discovers tools, reads schemas, imports capabilities, generates descriptions, builds permission requests, and displays available actions. Every MCP action runs under strict permission controls: Allow, Deny, Allow Once, Always Allow, and Revoke Later.

### Desktop Bridge MCP

Desktop Bridge lets Android OpenAssist connect to Windows, Linux, and macOS computers discovered on the local network or through secure remote endpoints such as Cloudflare Tunnel, Tailscale, custom domains, and HTTPS MCP endpoints. Supported actions include launching applications, running scripts, reading and writing files, executing commands, monitoring system status, transferring files, and remote workflows, all behind confirmation gates.

### MCP safety, memory, and workspace

MCP tools can create files, projects, images, documents, reports, and ZIP archives that appear automatically in Workspace. OpenAssist Memory can learn frequently used MCPs, tools, workflows, connected devices, and preferences. Sensitive MCP actions such as deleting files, sending emails, sending messages, running commands, executing scripts, making purchases, or modifying repositories must show tool name, MCP name, requested action, expected result, risk level, and Approve/Cancel controls.
